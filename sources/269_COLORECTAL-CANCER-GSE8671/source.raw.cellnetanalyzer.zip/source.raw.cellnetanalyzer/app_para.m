epsilon=1e-10;
basic_color=[0.7         0.7         0.7];
cr_color=[0.5         0.5           1];
br_color=[1         0.2         0.2];
nbr_color=[0.2           1         0.2];
text_color=[0  0  0];
macro_synth_color=[0  0  1];
macro_color=[0.9         0.9         0.5];
box_reaction_width=[0.009];
box_reaction_height=[0.009];
box_macro_width=[0.009];
box_macro_height=[0.009];
fontsize_reaction=[7];
fontsize_macro=[7];
fluxmaps={
'Network Map','C:\Users\fk163\Google Drive\Papers\CNA99_for_MATLAB75_or_higher\CellNetAnalyzer_for_MATLAB75_or_higher\CRC_Model_GSE8671_Khan\CRC_Model_map.png'
};
